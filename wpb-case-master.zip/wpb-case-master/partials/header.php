<?php defined('ABSPATH') || exit('Forbidden'); ?>

<header>
  <div class="container">
      Header
  </div>
</header>

<main>

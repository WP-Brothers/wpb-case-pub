<?php defined('ABSPATH') || exit('Forbidden'); ?>

</main>

<footer>
  <div class="container">
    Footer
  </div>
</footer>